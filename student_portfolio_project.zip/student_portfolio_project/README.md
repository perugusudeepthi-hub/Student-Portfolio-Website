# Student Portfolio Website

A beginner-friendly, responsive multi-page portfolio inspired by the HTML fundamentals covered in the referenced freeCodeCamp tutorial.

## Files
- `index.html` — home page and skills overview
- `about.html` — student introduction and learning goals
- `projects.html` — sample project cards
- `contact.html` — accessible contact form demo
- `style.css` — responsive styling and layouts
- `script.js` — mobile menu, current year, and form validation

## How to run
1. Extract the project folder.
2. Open `index.html` in a modern browser, or open the folder in Visual Studio Code and use Live Server.
3. Use the navigation to visit About, Projects, and Contact.
4. Try submitting the contact form with valid entries.

## Technologies
HTML5, CSS3, JavaScript (vanilla).

## Learning outcomes
- Semantic HTML page structure and metadata
- Headings, paragraphs, links, lists, and form elements
- CSS layout, cards, colors, responsive media queries, and hover states
- JavaScript DOM events, mobile navigation, form validation, and dynamic year

## Note
The contact form is a front-end demonstration only. It does not store or transmit submitted information. Add a backend or a trusted form service if real message delivery is needed.
