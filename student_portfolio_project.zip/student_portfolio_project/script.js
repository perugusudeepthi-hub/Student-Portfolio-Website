// Mobile navigation and small interactive enhancements.
document.addEventListener('DOMContentLoaded', () => {
  document.querySelectorAll('.year').forEach((element) => {
    element.textContent = new Date().getFullYear();
  });

  const toggle = document.querySelector('.menu-toggle');
  const nav = document.querySelector('.nav-links');
  if (toggle && nav) {
    toggle.addEventListener('click', () => {
      const isOpen = nav.classList.toggle('open');
      toggle.setAttribute('aria-expanded', String(isOpen));
      toggle.textContent = isOpen ? '✕' : '☰';
    });
  }

  const form = document.querySelector('#contactForm');
  if (form) {
    form.addEventListener('submit', (event) => {
      event.preventDefault();
      const status = document.querySelector('#formStatus');
      if (!form.checkValidity()) {
        form.reportValidity();
        status.textContent = 'Please complete all fields correctly.';
        status.className = 'form-status error';
        return;
      }
      const name = document.querySelector('#name').value.trim();
      status.textContent = `Thanks, ${name}! The form passed validation. This demo does not send your message.`;
      status.className = 'form-status success';
      form.reset();
    });
  }
});
